// Função para realizar cálculos utilizando a estrutura IF
function calcularComIf() {
    let valor1 = parseFloat(document.getElementById('valor1').value);
    let valor2 = parseFloat(document.getElementById('valor2').value);
    let resultado = 0;
    let operacao = prompt("Escolha a operação (+, -, *, /):");

    if (operacao === "+") {
        resultado = valor1 + valor2;
    } else if (operacao === "-") {
        resultado = valor1 - valor2;
    } else if (operacao === "*") {
        resultado = valor1 * valor2;
    } else if (operacao === "/") {
        if (valor2 !== 0) {
            resultado = valor1 / valor2;
        } else {
            alert("Não é possível dividir por zero!");
            return;
        }
    } else {
        alert("Operação inválida.");
        return;
    }

    document.getElementById('resultado').value = resultado;
}

// Função para realizar cálculos utilizando a estrutura Switch
function calcularComSwitch() {
    let valor1 = parseFloat(document.getElementById('valor1').value);
    let valor2 = parseFloat(document.getElementById('valor2').value);
    let resultado = 0;
    let operacao = prompt("Escolha a operação (+, -, *, /):");

    switch (operacao) {
        case "+":
            resultado = valor1 + valor2;
            break;
        case "-":
            resultado = valor1 - valor2;
            break;
        case "*":
            resultado = valor1 * valor2;
            break;
        case "/":
            if (valor2 !== 0) {
                resultado = valor1 / valor2;
            } else {
                alert("Não é possível dividir por zero!");
                return;
            }
            break;
        default:
            alert("Operação inválida.");
            return;
    }

    document.getElementById('resultado').value = resultado;
}
